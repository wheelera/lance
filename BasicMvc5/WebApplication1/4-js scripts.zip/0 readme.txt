The included set of files represent how the Script Documents node changes when running the code in Debug mode for an MVC project.  I took these screenshots using my current project, but if you simply create a new MVC project the same behavior will be observered.  Create the project as:
  MVC
  Add unit Tests
  Individual User Accounts

There are 4 .PNG screen shots of the node, each beginning with a number representing the intial click actions taken in the MVC project under debug
Then there are a set of files beginning with the same number that show or explain what each document in the node contains for that click action
I did not record the individual .js files because they are what they are, unchanged
I took some shortcuts naming the files, but I hope they are understandable.  I include a picture with each click for the previous page document

The 4 click actions are:
  1 - startup, before any clicks are undertaken
  2 - clicking on Log in, but without any other clicks
  3 - entering log in data and clicking on Log in
  4 - clicking into the About page

My observations:
  There is an initial landingpage.html document that I really don't understand the significance of, for me.
  With each click action a new 'page' document is created that shows the HTML for that page, and a set of .js scripts that run
  But with each new click, the previous document page is changed and looks to me to be a copy of the initial landingpage.html

The list grows continuously with each click action
